package com.jd.springgear.extend.jsf.engine;

import com.google.common.collect.Lists;
import com.jd.jsf.gd.util.RpcContext;
import com.jd.springgear.engine.AbstractSpringGearEngineExecutor;
import com.jd.springgear.exception.GearInterruptException;
import com.jd.springgear.support.constants.HttpStatus;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

/**
 * @author wangshuai131 (<a href="mailto:wangshuai30@jd.com">wangshuai30@jd.com</a>)
 * @since 2020/12/13
 **/
@Slf4j
public class JsfSpringGearEngineExecutor extends AbstractSpringGearEngineExecutor {

    private final static String JSF_PARAMETER_SOURCE = "source";

    private final static String DEFAULT_SOURCE = "HTTP";

    /**
     * 杰夫来源参数
     */
    @Setter
    private String jsfParameterSource;

    /**
     * 默认来源
     */
    @Setter
    private String defaultSource;

    /**
     * 来源是否验证
     */
    @Setter
    private boolean verifySource = false;

    /**
     * 如果验证，允许的 source，default source 默认是被允许的
     */
    @Setter
    private List<String> allowSources;

    @Override
    public void afterPropertiesSet() throws Exception {
        super.afterPropertiesSet();
        if (jsfParameterSource == null) {
            jsfParameterSource = JSF_PARAMETER_SOURCE;
        }
        if (defaultSource == null) {
            defaultSource = DEFAULT_SOURCE;
        }
        if (allowSources == null) {
            allowSources = Lists.newArrayList();
        }
    }

    @Override
    protected String getSource() throws GearInterruptException {

        RpcContext rpcContext = RpcContext.getContext();

        // 标记是否为杰夫调用。
        boolean isJsfInvoke = (rpcContext.isProviderSide() && rpcContext.getAlias() != null);


        if (!isJsfInvoke) { // 非杰夫来源，认为是 http 请求
            return this.defaultSource;
        }

        String source = (String) rpcContext.getAttachment(this.jsfParameterSource);

        if (source == null) {
            throw new GearInterruptException("请为 <jsf:consumer> 添加名为 'source' 的 parameter。", HttpStatus.SC_BAD_REQUEST);
        } else {
            log.info("SOURCE[{}] REMOTE[{}] ALIAS[{}]", source, rpcContext.getRemoteHostName(), rpcContext.getAlias());
        }

        if (false == this.verifySource) {
            return source;
        }

        if (false == allowSources.contains(source)) {
            throw new GearInterruptException(String.format("source '%s' 不在允许使用的范围内。", source), HttpStatus.SC_FORBIDDEN);
        }

        return source;
    }
}
